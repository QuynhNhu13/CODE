#include<stdio.h>

int main(){
	
	int dd, mm, yyyy;
	
	printf ("Input dd mm yyyy: ");
	scanf ("%d%d%d", &dd, &mm, &yyyy);
	

	if (yyyy%400==0||(yyyy%4==0&&yyyy%100!=0)){
		
	
		if (dd<1||dd>31||1>mm||mm>12||((mm==4)||(mm==6)||(mm==9)||(mm==11)&&dd>30)||(mm==2&&dd>29)){
			printf ("Invalid date");
		} else {
			printf ("Valid date");
		}	
		
		
	} else {
		if (dd<1||dd>31||1>mm||mm>12||((mm==4)||(mm==6)||(mm==9)||(mm==11)&&dd>30)||(mm==2&&dd>28)){
			printf ("Invalid date");
		} else {
			printf ("Valid date");
		}
	}

	return 0;
}
