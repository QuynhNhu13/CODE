#include<stdio.h>

int main(){
	
	int x,y,z;
	printf ("Enter x: ");
	scanf ("%d", &x);
	printf ("Enter y: ");
	scanf ("%d", &y);
	
	z=x;
	x=y;
	y=z;
	
	printf ("Swap Success!!! x = %d, y = %d", x,y);
	
	return 0;
	
}
